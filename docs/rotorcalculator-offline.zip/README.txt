RotorCalculator 1.33 — Offline web application

Extract this ZIP, then open index.html in a modern browser.
Keep the assets folder and bundled manuals beside index.html.
Geometry import/export and sweep CSV/PNG work offline.
For home-screen installation, use the hosted HTTPS web app.
